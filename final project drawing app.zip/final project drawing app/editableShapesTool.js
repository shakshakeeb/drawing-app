//var editButton;
//var finishButton;
//
//
//
//var editMode = false;
//var currentShape = [];




function EditableShapesTool(){
    
    this.icon = "assets/editTool.jpg";
    this.name = "EditableShapes";
    
    var c;
    
    
    var editButton;
    var finishButton;



    var editMode = false;
    var currentShape = [];

    noFill();
    loadPixels();

    editButton = createButton('Edit Shape'); // add an edit /add vertices button
    editButton.mousePressed(function(){
        if(editMode){
            editMode = false;
            editButton.html("Edit Shape");
        }
        else{
            editMode = true;
            editButton.html("Add Vertices");
        }
    });
    
    finishButton = createButton('Finish Shape')
    
    finishButton.mousePressed(function(){
        editMode = false;
        this.draw();
        loadPixels();
        currentShape = [];
        
    })
    
     
    this.draw = function(){
        updatePixels();
        if(this.mousePressOnCanvas(c) && mouseIsPressed){
            
            if(!editMode){
                currentShape.push({
                    x: mouseX,
                    y: mouseY
                });
            }
  
        }
        else
        {
            for(var i = 0; i < currentShape.length; i++){
                if(dist(currentShape[i].x, currentShape[i].y, mouseX, mouseY) < 15){
                    currentShape[i].x = mouseX;
                    currentShape[i].y = mouseY;
                }
            }
        }
        
        beginShape();
        
        for(var i = 0; i < currentShape.length; i++){
            vertex(currentShape[i].x,
            currentShape[i].y);
            if(editMode){
                fill('red');
                ellipse(currentShape[i].x, currentShape[i].y, 15);
                noFill();
            }
        }
        endShape();
    }
    
    
    
    this.mousePressOnCanvas = function(c){
        
        canvasContainer = select('#content');
        var c = createCanvas(canvasContainer.size().width, canvasContainer.size().height);
        c.parent('#content');
            if (mouseX >  c.elt.offsetLeft && // stop the image from carrying on mouse press
                mouseX < (c.elt.offsetLeft + 
                c.width) &&
                mouseY > c.elt.offsetTop &&
                mouseY < (c.elt.offsetTop +
                c.height) )
            {
                return true;
            }
        return false;
    }
}