//This is an eraser tool, and is one of the ideas I have chosen. It will erase anything i draw on the canvasd
function EraserTool() {
    this.name = "eraser";
    this.icon = "assets/eraser.jpg";
    
    var spread = 20;
    
    var previousMouseX = -1;
	var previousMouseY = -1;

	this.draw = function(){

		if(mouseIsPressed){

			if (previousMouseX == -1){
				previousMouseX = mouseX;
				previousMouseY = mouseY;
			}

			else{
                strokeWeight(slider.value());
                fill(255);
                stroke(255);
				line(previousMouseX, previousMouseY, mouseX, mouseY);
				previousMouseX = mouseX;
				previousMouseY = mouseY;
			}
		}

		else{
			previousMouseX = -1;
			previousMouseY = -1;
		}
	};
}
    
    
    
    
    
