function HelperFunctions() {

	//Jquery click events. Notice that there is no this. at the
	//start we don't need to do that here because the event will
	//be added to the button and doesn't 'belong' to the object

	//event handler for the clear button event. Clears the screen
	select("#clearButton").mouseClicked(function() {
		background(255, 255, 255);
		//call loadPixels to update the drawing state
		//this is needed for the mirror tool
		loadPixels();
	});

	//event handler for the save image button. saves the canvsa to the
	//local file system.
	select("#saveImageButton").mouseClicked(function() {
		saveCanvas("myPicture", "jpg");
	});
    
    select("#loadImageButton").mouseClicked(function() {
        let img = loadImage("/assets/smilyface.jpeg")
        image(img, 40,40);
    })

//function mousePressOnCanvas(canvas){
//        if (mouseX > (canvas.elt.offsetLeft &&
//            mouseX < (canvas.elt.offsetLeft + 
//            canvas.width)) &&
//            mouseY > canvas.elt.offsetTop &&
//            mouseY < (canvas.elt.offsetTop +
//            canvas.height)
//    ) {
//        return true;
//    }
//    return false;
//    
//    }
    
    
}