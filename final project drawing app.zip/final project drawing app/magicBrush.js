//function MagicBrush() {
//    this.name = "magicBrush";
//    this.icon = "assets/magicbrush.png";
//    
//    this.draw = function() {
//        colorMode(HSB);
//        
//    if(mouseIsPressed){
//        noStroke();
//        stroke((5*framecount) % 360, 40, 100);
//        fill((5*framecount) % 360, 100, 100);
//        
//        strokeWeight(slider.value());
//        line(previousMouseX, previousMouseY, mouseX, mouseY);
//    }
//    colorMode(RGB);
//    }
//}