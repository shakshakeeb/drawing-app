var img;


function StampTool() {
    this.name = "stampTool";
    this.icon = "assets/stamp.jpg";
     
    
    this.preload = function() {
        img = loadImage('assets/smilyface.jpeg');
    }
    
    this.setup = function() {
        canvasContainer = select('#content');
        c = createCanvas(canvasContainer.size().width, canvasContainer.size().height);
        c.parent("content");
        
        
    }

    this.draw = function() {
        
    }
    this.mousePressed = function() {
        image(img, mouseX, mouseY, 100,100);
        //console.log("stamp down");
    }
}